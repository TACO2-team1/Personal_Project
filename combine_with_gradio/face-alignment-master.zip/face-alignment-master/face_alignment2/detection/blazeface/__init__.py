from .blazeface_detector import BlazeFaceDetector as FaceDetector
